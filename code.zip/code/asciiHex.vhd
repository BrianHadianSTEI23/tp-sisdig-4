-- Template kode untuk ASCII - HEX (7 Segments) Converter
-- Kode ASCII yang harus diterjemahkan adalah:
-- angka 0, 1, 2, 3, 4, 5, 6, 7, 8, dan 9.
-- huruf A, B, C, D, E, F, G, H, I, dan J.
-- Tampilan pada HEX (7 Segments) sebagai berikut:
-- 1 -> 1
-- 2 -> 2
-- 3 -> 3
-- 4 -> 4
-- 5 -> 5
-- 6 -> 6
-- 7 -> 7
-- 8 -> 8
-- 9 -> 9
-- 0 -> 0
-- A -> A
-- B -> b
-- C -> c
-- D -> d
-- E -> E
-- F -> F
-- G -> G
-- H -> H
-- I -> I (di sebelah kiri, tidak seperti angka 1)
-- J -> j (tanpa titik)


library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;


entity asciiHex is
	port	(
				i_ascii		:		in		std_logic_vector	(7 downto 0);
				0_hex		:		out		std_logic_vector	(6 downto 0)
			);
end asciiHex;


architecture behavior of asciiHex is
begin

	--- rancanglah arsitektur dari modul konverter ini.
	
end behavior;